# SCM4 iOS host source snapshot

This source accompanies an experimental unsigned iPhone device-test handoff.
It is not a claim of iPhone execution or a validated playable release.
Preserve the work/ layout when extracting. Original game programs,
artwork/audio/data, personal saves, signing credentials, the SDK and toolchain
binaries are not included. Their absence does not mean the host is standalone.

## Build prerequisites

- Windows x64 with Python 3.12 or later (original build: Python 3.14.5).
  NumPy 2.5.4 requires Python >=3.12. Create the exact expected environment:

  ```powershell
  python -m venv work/venv
  work/venv/Scripts/python.exe -m pip install -r requirements-source.lock
  ```
- Supply iPhoneOS16.5.sdk under work/sdk. The original development build used
  the public Theos SDK archive (SHA256
  5e0fd3f01266cce4ce012d4a99b38eb56578fca40d09edc81cd83dee958202fb).
  Keep its license terms. Materialize only in-tree SDK links on Windows.
  Archive URL: https://github.com/theos/sdks/releases/download/master-146e41f/iPhoneOS16.5.sdk.tar.xz
- Use the exact original user APK, SHA256
  eaefe9c8e0c61ec8a6a29f535928497cb476da08f9fa75d1879cf74953452e16.
  Its nested assets/bundled/scm4-guest.apk supplies lib/armeabi-v7a, audio,
  game data and res_pad overlays. Keep a copy of that nested APK under
  work/apk/assets/bundled: build_ios.py reads its original app icon.
- The launcher within that APK is hash-checked by prepare_guest.py.

Prepare these external inputs with the included bounded extractor. It checks
both archive SHA256 values, extracts guest libraries/assets, preserves the
nested APK and materializes safe in-tree SDK links:

```powershell
work/venv/Scripts/python.exe prepare_external_inputs.py --apk C:/path/SCM4-user.apk --sdk-archive C:/path/iPhoneOS16.5.sdk.tar.xz
```

## iOS host build

Run from the extracted archive's root using work/venv/Scripts/python.exe:

1. work/analysis/build_agent/build_engine_from_manifest.py
2. work/ios_port/prepare_guest.py
3. work/ios_port/prepare_audio.py
4. work/ios_port/prepare_notices.py
5. work/ios_port/build_ios.py
6. work/ios_port/audit_ipa.py work/ios_port/build-ios/SCM4-development-unsigned.ipa

The engine recipe uses source-manifest.json rather than machine-specific VS
project paths. The original build_ios_tci.py is retained as provenance.
The iOS build route needs no Visual Studio or CMake. It builds the 67 C sources
listed in the manifest with Zig, then links the UIKit Objective-C host.
The output still needs signing and a physical-device test; review
work/ios_port/README-INSTALL-INTERNAL.md. Never put signing secrets in sources.

The host GPL notice and full third-party licenses are in work/ios_port. The
guest programs and their content retain their original terms. This archive
does not grant original-game redistribution rights or relicense old handoffs.

## Optional Windows regression checks

build_probe.py and validate_integration.py additionally require Visual Studio
2022's C++ tools and CMake. Generate the ARM-only host engine first:

```powershell
cmake -S work/analysis/interpreter_agent/unicorn-tci -B work/analysis/interpreter_agent/build-tci -G "Visual Studio 17 2022" -A x64 -DUNICORN_ARCH=arm -DUNICORN_INTERPRETER=ON -DUNICORN_BUILD_TESTS=ON -DUNICORN_INSTALL=OFF
cmake --build work/analysis/interpreter_agent/build-tci --config Release --target unicorn test_arm --parallel 4
work/analysis/interpreter_agent/build-tci/Release/test_arm.exe
work/venv/Scripts/python.exe work/ios_port/validate_integration.py
```

The reference frame/save hashes used by validate_integration.py are included
in work/analysis/interpreter_agent/variant-report.json. Those tests require
the prepared Guest and Audio data. The old build_ios_tci.py and source snapshot
generator depend on the original developer's Git/Visual Studio build metadata;
they are provenance tools, not prerequisites for rebuilding this archive.
Use build_engine_from_manifest.py for the portable iOS engine rebuild.

SOURCE-MANIFEST.json hashes every source file and identifies the inspected IPA.
BINARY-PROVENANCE.json was read from that IPA; all its compiled host-source
hashes and the linked engine-library hash were checked before this snapshot.
After a source change, rebuild the IPA and regenerate the source ZIP in the
original development workspace. A static audit does not establish behavior
on a physical iPhone or promise byte-identical output across toolchains.
