"""Materialize SDK archive symlinks as copies on Windows; no administrator rights."""
from pathlib import Path
import os
import shutil
import tarfile

ROOT = Path(__file__).resolve().parents[3]
sdk_root = ROOT / 'work' / 'sdk'
archive = Path(__file__).with_name('iPhoneOS16.5.sdk.tar.xz')
def long(path):
    return Path('\\\\?\\' + str(path)) if os.name == 'nt' else path

with tarfile.open(archive) as source:
    pending = [entry for entry in source.getmembers() if entry.issym() or entry.islnk()]
while pending:
    remaining = []
    for entry in pending:
        destination = Path(os.path.abspath(sdk_root / entry.name))
        target = Path(os.path.abspath((destination.parent if entry.issym() else sdk_root) / entry.linkname))
        if not destination.is_relative_to(sdk_root) or not target.is_relative_to(sdk_root):
            raise ValueError(f'Escaping SDK link: {entry.name}')
        src, dst = long(target), long(destination)
        if dst.exists():
            continue
        if not src.exists():
            remaining.append(entry)
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            shutil.copytree(src, dst)
        else:
            shutil.copyfile(src, dst)
    if len(remaining) == len(pending):
        print('Unresolved optional SDK links:', [item.name for item in remaining])
        break
    pending = remaining
print('SDK link materialization complete')
