from pathlib import Path
import json
import struct
import subprocess
import hashlib
import imageio_ffmpeg

ROOT = Path(__file__).resolve().parents[3]
source = ROOT / 'work/apk/guest/assets/snd/90.ogg'
data = source.read_bytes()
pages = []
offset = 0
while offset < len(data):
    if data[offset:offset + 4] != b'OggS':
        raise ValueError(f'Ogg capture missing at {offset}')
    segments = data[offset + 26]
    sizes = data[offset + 27:offset + 27 + segments]
    end = offset + 27 + segments + sum(sizes)
    page = bytearray(data[offset:end])
    expected_crc = struct.unpack_from('<I', page, 22)[0]
    page[22:26] = b'\0' * 4
    crc = 0
    for byte in page:
        crc ^= byte << 24
        for _ in range(8):
            crc = ((crc << 1) ^ (0x04C11DB7 if crc & 0x80000000 else 0)) & 0xFFFFFFFF
    pages.append({'offset': offset, 'bytes': end-offset, 'header_flags': data[offset + 5],
                  'granule': struct.unpack_from('<Q', data, offset + 6)[0],
                  'sequence': struct.unpack_from('<I', data, offset + 18)[0],
                  'segment_sizes': list(sizes), 'crc_valid': crc == expected_crc})
    offset = end
ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
out = source.parent / '90-audit.wav'
# Keep diagnostics outside the original asset tree.
out = Path(__file__).parent / '90-ffmpeg.wav'
proc = subprocess.run([ffmpeg, '-hide_banner', '-nostdin', '-y', '-i', str(source),
                       '-c:a', 'pcm_s16le', str(out)], capture_output=True, text=True)
report = {'source_sha256': hashlib.sha256(data).hexdigest(), 'source_bytes': len(data),
          'pages': pages, 'ffmpeg_exit': proc.returncode, 'ffmpeg_log': proc.stderr,
          'wav_bytes': out.stat().st_size if out.exists() else None}
Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
