"""Rebuild the exact ARM-only iOS TCI source list captured in source-manifest.json.

This avoids machine-specific Visual Studio project files in a source handoff.
Run from a source-bundle checkout retaining its work/ directory layout.
"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import json
import os
import subprocess

ROOT = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--sdk', type=Path, default=ROOT / 'work/sdk/iPhoneOS16.5.sdk')
parser.add_argument('--zig', type=Path, default=ROOT / 'work/venv/Lib/site-packages/ziglang/zig.exe')
parser.add_argument('--jobs', type=int, default=4)
args = parser.parse_args()
src = ROOT / 'work/analysis/interpreter_agent/unicorn-tci'
out = ROOT / 'work/build-ios-tci'
manifest = json.loads((out / 'source-manifest.json').read_text('utf-8'))
env = dict(os.environ, ZIG_GLOBAL_CACHE_DIR=str(ROOT / 'work/zig-cache'),
           ZIG_LOCAL_CACHE_DIR=str(ROOT / 'work/zig-local-cache'))
(out / 'arm-softmmu').mkdir(parents=True, exist_ok=True)
(out / 'config-host.h').write_text(manifest['config_host'], encoding='utf-8')
(out / 'arm-softmmu/config-target.h').write_text(manifest['config_target'], encoding='utf-8')
common = [str(args.zig), 'cc', '-target', 'aarch64-ios.16.0', '-isysroot', str(args.sdk),
          '-isystem', str(args.sdk / 'usr/include'), '-std=gnu11', '-O2', '-fPIC',
          '-DNDEBUG', '-DUNICORN_HAS_ARM', '-DOS_OBJECT_USE_OBJC=0', '-D_GNU_SOURCE',
          '-DCONFIG_TCG_INTERPRETER=1', '-Wno-deprecated-declarations',
          '-Wno-incompatible-pointer-types', '-Wno-int-conversion']
for inc in (out, src/'glib_compat', src/'qemu', src/'qemu/include', src/'include', src/'qemu/tcg', src/'qemu/tcg/tci'):
    common += ['-I', str(inc)]

def compile_one(item):
    obj = out / (item['source'].replace('/', '_') + '.o')
    command = list(common)
    if item['target'] == 'arm-softmmu':
        command += ['-DNEED_CPU_H', '-include', 'arm.h', '-I', str(out/'arm-softmmu'), '-I', str(src/'qemu/target/arm')]
    command += ['-c', str(src/item['source']), '-o', str(obj)]
    proc = subprocess.run(command, env=env, text=True, capture_output=True)
    if proc.returncode:
        raise RuntimeError(item['source'] + '\n' + proc.stderr)
    return obj

with ThreadPoolExecutor(max_workers=args.jobs) as pool:
    objects = list(pool.map(compile_one, manifest['sources']))
subprocess.run([str(args.zig), 'ar', 'rcs', str(out/'libunicorn-tci.a'), *map(str, objects)], env=env, check=True)
print('Built', len(objects), 'ARM-only TCI sources')
