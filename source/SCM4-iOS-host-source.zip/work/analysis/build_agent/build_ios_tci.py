"""Cross-build the ARM guest / TCI host library for iOS on Windows.

The source list comes from upstream CMake's configured ARM-only targets.
Only the Windows OS support source files are replaced by upstream POSIX files.
No compiler, SDK, cache or installation outside this workspace is modified.
"""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
SRC = ROOT / 'work/analysis/interpreter_agent/unicorn-tci'
HOST = SRC.parent / 'build-tci'
OUT = ROOT / 'work/build-ios-tci'
SDK = ROOT / 'work/sdk/iPhoneOS16.5.sdk'
ZIG = ROOT / 'work/venv/Lib/site-packages/ziglang/zig.exe'
ENV = dict(os.environ, ZIG_GLOBAL_CACHE_DIR=str(ROOT / 'work/zig-cache'),
           ZIG_LOCAL_CACHE_DIR=str(ROOT / 'work/zig-local-cache'))
OUT.mkdir(exist_ok=True)
(OUT / 'arm-softmmu').mkdir(exist_ok=True)
(OUT / 'config-host.h').write_text('''/* iOS/ARM64 TCI cross-build configuration */
#define HOST_AARCH64 1
#define CONFIG_POSIX 1
#define CONFIG_DARWIN 1
#define CONFIG_POSIX_MEMALIGN 1
#define CONFIG_TCG 1
#define CONFIG_TCG_INTERPRETER 1
#define CONFIG_INT128 1
#define CONFIG_ATOMIC64 1
#define CONFIG_PLUGIN 1
#define CONFIG_CLOCK_GETTIME 1
''')
(OUT / 'arm-softmmu/config-target.h').write_text('''#define TARGET_ARM 1
#define TARGET_NAME "arm"
#define CONFIG_SOFTMMU 1
''')

NS = {'m': 'http://schemas.microsoft.com/developer/msbuild/2003'}
jobs = []
for target in ('unicorn-common', 'arm-softmmu', 'unicorn'):
    tree = ET.parse(HOST / (target + '.vcxproj'))
    for node in tree.findall('.//m:ClCompile', NS):
        if not node.get('Include'):
            continue
        src = Path(node.get('Include'))
        if src.name in ('oslib-win32.c', 'qemu-thread-win32.c'):
            src = src.with_name(src.name.replace('win32', 'posix'))
        jobs.append((target, src))

headers = hashlib.sha256()
for header in sorted(SRC.rglob('*.h')):
    headers.update(header.read_bytes())
headers.update((OUT / 'config-host.h').read_bytes())
header_digest = headers.hexdigest()

common = [str(ZIG), 'cc', '-target', 'aarch64-ios.16.0', '-isysroot', str(SDK),
          '-isystem', str(SDK / 'usr/include'), '-std=gnu11', '-O2', '-fPIC',
          '-DNDEBUG', '-DUNICORN_HAS_ARM', '-DOS_OBJECT_USE_OBJC=0',
          '-D_GNU_SOURCE', '-DCONFIG_TCG_INTERPRETER=1',
          '-Wno-deprecated-declarations', '-Wno-incompatible-pointer-types',
          '-Wno-int-conversion']
for inc in (OUT, SRC / 'glib_compat', SRC / 'qemu', SRC / 'qemu/include',
            SRC / 'include', SRC / 'qemu/tcg', SRC / 'qemu/tcg/tci'):
    common.extend(['-I', str(inc)])

def compile_one(job):
    target, src = job
    relative = src.relative_to(SRC).as_posix()
    obj = OUT / (relative.replace('/', '_') + '.o')
    args = list(common)
    if target == 'arm-softmmu':
        args += ['-DNEED_CPU_H', '-include', 'arm.h', '-I', str(OUT / 'arm-softmmu'),
                 '-I', str(SRC / 'qemu/target/arm')]
    args += ['-c', str(src), '-o', str(obj)]
    stamp = hashlib.sha256((header_digest + json.dumps(args) + src.read_text()).encode()).hexdigest()
    stamp_file = obj.with_suffix('.stamp')
    if obj.exists() and stamp_file.exists() and stamp_file.read_text() == stamp:
        return relative, obj, None
    result = subprocess.run(args, capture_output=True, text=True, env=ENV)
    if result.returncode:
        return relative, obj, result.stderr
    stamp_file.write_text(stamp)
    return relative, obj, None

with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(compile_one, jobs))
errors = {name: error for name, obj, error in results if error}
(OUT / 'compile-errors.json').write_text(json.dumps(errors, indent=2))
for name, error in errors.items():
    print(name, error[:2500], flush=True)
print(f'Compiled {len(results)-len(errors)}/{len(results)} sources', flush=True)
if errors:
    raise SystemExit(1)
subprocess.run([str(ZIG), 'ar', 'rcs', str(OUT / 'libunicorn-tci.a')]
               + [str(obj) for _, obj, _ in results], check=True, env=ENV)
print('Created', OUT / 'libunicorn-tci.a')
