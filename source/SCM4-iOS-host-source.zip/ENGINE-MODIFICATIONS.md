# Local engine changes

Snapshot date: 2026-11-10 (Asia/Seoul).
The included engine is the source actually used by this port, including local
edits. engine-local-changes.patch records changes against the pinned upstream
commit. The changes select the TCI backend for Windows tests, keep translated
bytecode buffers non-executable, correct MSVC opcode configuration, and add
missing-op diagnostics. Per-file copyright/license notices are preserved.
The manifest records each file hash and exact iOS source list/configuration.
