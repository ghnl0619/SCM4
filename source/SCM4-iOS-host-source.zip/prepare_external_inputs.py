"""Materialize exact user APK and SDK inputs inside this source checkout."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import io
import os
import shutil
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apk', required=True, type=Path)
parser.add_argument('--sdk-archive', required=True, type=Path)
args = parser.parse_args()
expected = {
    args.apk: 'eaefe9c8e0c61ec8a6a29f535928497cb476da08f9fa75d1879cf74953452e16',
    args.sdk_archive: '5e0fd3f01266cce4ce012d4a99b38eb56578fca40d09edc81cd83dee958202fb',
}
for path, digest in expected.items():
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise SystemExit('Input hash mismatch: ' + str(path))

def long(path):
    return Path(chr(92)*2 + '?' + chr(92) + str(path.resolve())) if os.name == 'nt' else path

def target(root, name):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or chr(92) in name or ':' in name:
        raise ValueError('Unsafe archive path: ' + name)
    candidate = root.joinpath(*path.parts)
    if not candidate.resolve().is_relative_to(root.resolve()) or candidate.is_symlink():
        raise ValueError('Escaping archive path: ' + name)
    return long(candidate)

with zipfile.ZipFile(args.apk) as outer:
    guest = outer.read('assets/bundled/scm4-guest.apk')
nested = ROOT/'work/apk/assets/bundled/scm4-guest.apk'
nested.parent.mkdir(parents=True, exist_ok=True)
nested.write_bytes(guest)  # build_ios.py also reads the original icon here.
with zipfile.ZipFile(io.BytesIO(guest)) as inner:
    for entry in inner.infolist():
        if entry.is_dir() or not entry.filename.startswith(('lib/armeabi-v7a/', 'assets/')):
            continue
        destination = target(ROOT/'work/apk/guest', entry.filename)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(inner.read(entry))
sdk_root = ROOT/'work/sdk'
sdk_root.mkdir(parents=True, exist_ok=True)
with tarfile.open(args.sdk_archive) as sdk:
    for entry in sdk:
        if not entry.isfile():
            continue  # links are materialized with bounds checks below.
        destination = target(sdk_root, entry.name)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with sdk.extractfile(entry) as source, destination.open('wb') as output:
            shutil.copyfileobj(source, output)
stored_sdk = ROOT/'work/analysis/build_agent/iPhoneOS16.5.sdk.tar.xz'
if stored_sdk.resolve() != args.sdk_archive.resolve():
    shutil.copyfile(args.sdk_archive, stored_sdk)
subprocess.run([sys.executable, str(stored_sdk.with_name('materialize_sdk_links.py'))], check=True)
print('Prepared exact guest APK, assets, icon source and iOS SDK inside this checkout')
